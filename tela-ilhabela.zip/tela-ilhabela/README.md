# Tela Ilhabela

Protótipo de uma Discord Activity para compartilhamento de tela usando:

- Discord Embedded App SDK
- Vite
- Node.js + Express
- WebSocket para sinalização
- WebRTC para transporte de áudio/vídeo
- `getDisplayMedia()` para solicitar a captura de tela

## 1. Instalar

```bash
npm install
```

## 2. Configurar

Copie `.env.example` para `.env` e coloque o Client ID da sua aplicação Discord:

```env
VITE_DISCORD_CLIENT_ID=SEU_CLIENT_ID
PORT=3000
PUBLIC_ORIGIN=http://localhost:3000
```

## 3. Rodar

```bash
npm run dev
```

O servidor fica na porta 3000 e o Vite usa outra porta para desenvolvimento.

## 4. Discord Activity

No Developer Portal:

1. Crie uma aplicação.
2. Ative Activities.
3. Configure um URL Mapping apontando para o endereço público da aplicação.
4. Use o Client ID no `.env`.
5. Adicione testadores à aplicação enquanto estiver não verificada.

O Discord exige URL Mapping para habilitar Activities.

## 5. Produção

Use HTTPS. Para WebRTC em produção, mantenha um servidor de sinalização como este e adicione TURN (por exemplo, coturn) para redes onde conexão direta não funcionar.

### Importante sobre captura

`getDisplayMedia()` depende do suporte do ambiente e da permissão do usuário. O código não tenta capturar tela silenciosamente: o usuário sempre precisa autorizar a captura.

O projeto é um protótipo funcional da arquitetura; antes de publicar, teste `getDisplayMedia()` especificamente no cliente Discord e nas plataformas que você pretende suportar.

## Segurança

- Não coloque Client Secret no frontend.
- Não confie em IDs de sala fornecidos pelo cliente para autorização.
- Em produção, autentique participantes e aplique controle de acesso.
- Considere limitar bitrate, tamanho das salas e quantidade de espectadores.
