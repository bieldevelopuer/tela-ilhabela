import express from "express";
import http from "http";
import path from "path";
import { fileURLToPath } from "url";
import { WebSocketServer } from "ws";
import cors from "cors";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.resolve(__dirname, "..");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });

app.use(cors());
app.use(express.json());
app.use(express.static(root));

const rooms = new Map();

function send(ws, payload) {
  if (ws.readyState === 1) ws.send(JSON.stringify(payload));
}

function broadcast(room, except, payload) {
  for (const client of room) {
    if (client !== except) send(client, payload);
  }
}

wss.on("connection", (ws) => {
  ws.id = crypto.randomUUID();
  ws.room = null;

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); }
    catch { return; }

    if (msg.type === "join") {
      const roomId = String(msg.roomId || "ilhabela").slice(0, 32);
      if (!rooms.has(roomId)) rooms.set(roomId, new Set());

      const room = rooms.get(roomId);
      const peers = [...room].map(client => client.id);

      ws.room = roomId;
      room.add(ws);

      send(ws, { type: "peers", peers });
      broadcast(room, ws, { type: "peer-joined", peerId: ws.id });
      return;
    }

    if (!ws.room) return;
    const room = rooms.get(ws.room);
    if (!room) return;

    if (["offer", "answer", "ice"].includes(msg.type) && msg.to) {
      const target = [...room].find(client => client.id === msg.to);
      if (target) send(target, { ...msg, from: ws.id });
    }
  });

  ws.on("close", () => {
    if (!ws.room) return;
    const room = rooms.get(ws.room);
    if (!room) return;

    room.delete(ws);
    broadcast(room, ws, { type: "peer-left", peerId: ws.id });

    if (room.size === 0) rooms.delete(ws.room);
  });
});

app.get("/health", (_req, res) => res.json({ ok: true, app: "Tela Ilhabela" }));

const port = Number(process.env.PORT || 3000);
server.listen(port, "0.0.0.0", () => {
  console.log(`Tela Ilhabela: http://localhost:${port}`);
});
