import { DiscordSDK } from "@discord/embedded-app-sdk";
import "./style.css";

const clientId = import.meta.env.VITE_DISCORD_CLIENT_ID;
const app = document.querySelector("#app");

let discordSdk = null;
let localStream = null;
let ws = null;
let roomId = "ilhabela";
let peers = new Map();

function render() {
  app.innerHTML = `
    <main class="shell">
      <header class="topbar">
        <div>
          <div class="brand">Tela Ilhabela</div>
          <div class="sub">Compartilhamento de tela dentro da Activity</div>
        </div>
        <div id="status" class="status">Iniciando...</div>
      </header>

      <section class="stage">
        <div class="video-wrap">
          <video id="remoteVideo" autoplay playsinline></video>
          <div id="empty" class="empty">
            <div class="screen-icon">▣</div>
            <h2>Ninguém está compartilhando</h2>
            <p>Quando alguém iniciar uma transmissão, ela aparecerá aqui.</p>
          </div>
        </div>

        <aside class="panel">
          <label>Sala</label>
          <div class="room">
            <input id="roomId" value="${roomId}" maxlength="32" />
            <button id="joinBtn">Entrar</button>
          </div>

          <button id="shareBtn" class="primary">🖥️ Compartilhar minha tela</button>
          <button id="stopBtn" class="danger" disabled>■ Parar compartilhamento</button>

          <div class="hint">
            <b>Como funciona</b>
            <p>O navegador/Discord pedirá autorização antes de capturar a tela. A transmissão usa WebRTC entre os participantes.</p>
          </div>
        </aside>
      </section>

      <footer>⚠️ Compartilhe somente conteúdo que você tem autorização para transmitir.</footer>
    </main>
  `;

  document.querySelector("#joinBtn").onclick = joinRoom;
  document.querySelector("#shareBtn").onclick = startSharing;
  document.querySelector("#stopBtn").onclick = stopSharing;
}

function setStatus(text) {
  const el = document.querySelector("#status");
  if (el) el.textContent = text;
}

async function setupDiscord() {
  if (!clientId) {
    setStatus("Modo navegador");
    return;
  }

  try {
    discordSdk = new DiscordSDK(clientId);
    await discordSdk.ready();
    setStatus("Discord conectado");
  } catch (err) {
    console.warn("Discord SDK não disponível:", err);
    setStatus("Modo navegador");
  }
}

function connectSocket() {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  ws = new WebSocket(`${proto}://${location.host}/ws`);

  ws.onopen = () => {
    ws.send(JSON.stringify({ type: "join", roomId }));
  };

  ws.onmessage = async (event) => {
    const msg = JSON.parse(event.data);
    if (msg.type === "peers") {
      for (const peerId of msg.peers) createPeer(peerId, true);
    }
    if (msg.type === "peer-joined") createPeer(msg.peerId, false);
    if (msg.type === "offer") {
      const pc = createPeer(msg.from, false);
      await pc.setRemoteDescription(msg.offer);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      send({ type: "answer", to: msg.from, answer });
    }
    if (msg.type === "answer") {
      const pc = peers.get(msg.from);
      if (pc) await pc.setRemoteDescription(msg.answer);
    }
    if (msg.type === "ice") {
      const pc = peers.get(msg.from);
      if (pc && msg.candidate) await pc.addIceCandidate(msg.candidate);
    }
    if (msg.type === "peer-left") {
      const pc = peers.get(msg.peerId);
      if (pc) pc.close();
      peers.delete(msg.peerId);
    }
  };

  ws.onclose = () => {
    setStatus("Servidor desconectado");
  };
}

function send(message) {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify(message));
}

function createPeer(peerId, initiator) {
  if (peers.has(peerId)) return peers.get(peerId);

  const pc = new RTCPeerConnection({
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
  });

  peers.set(peerId, pc);

  if (localStream) {
    localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
  }

  pc.onicecandidate = ({ candidate }) => {
    if (candidate) send({ type: "ice", to: peerId, candidate });
  };

  pc.ontrack = ({ streams }) => {
    const video = document.querySelector("#remoteVideo");
    const empty = document.querySelector("#empty");
    if (streams[0]) {
      video.srcObject = streams[0];
      empty.style.display = "none";
    }
  };

  pc.onconnectionstatechange = () => {
    if (["failed", "closed", "disconnected"].includes(pc.connectionState)) {
      pc.close();
      peers.delete(peerId);
    }
  };

  if (initiator) {
    pc.createOffer()
      .then(offer => pc.setLocalDescription(offer))
      .then(() => send({ type: "offer", to: peerId, offer: pc.localDescription }));
  }

  return pc;
}

async function startSharing() {
  try {
    localStream = await navigator.mediaDevices.getDisplayMedia({
      video: { frameRate: { ideal: 30, max: 60 } },
      audio: true
    });

    document.querySelector("#shareBtn").disabled = true;
    document.querySelector("#stopBtn").disabled = false;
    setStatus("Transmitindo");

    for (const [peerId, pc] of peers) {
      for (const track of localStream.getTracks()) {
        pc.addTrack(track, localStream);
      }
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      send({ type: "offer", to: peerId, offer: pc.localDescription });
    }

    localStream.getVideoTracks()[0].addEventListener("ended", stopSharing);
  } catch (err) {
    console.error(err);
    setStatus("Captura cancelada");
  }
}

function stopSharing() {
  if (!localStream) return;

  localStream.getTracks().forEach(track => track.stop());
  localStream = null;

  document.querySelector("#shareBtn").disabled = false;
  document.querySelector("#stopBtn").disabled = true;
  setStatus("Conectado");

  for (const pc of peers.values()) {
    pc.getSenders().forEach(sender => {
      if (sender.track) pc.removeTrack(sender);
    });
  }
}

function joinRoom() {
  const value = document.querySelector("#roomId").value.trim();
  if (!value) return;

  roomId = value.toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 32) || "ilhabela";

  if (ws) ws.close();
  for (const pc of peers.values()) pc.close();
  peers.clear();

  document.querySelector("#empty").style.display = "flex";
  document.querySelector("#remoteVideo").srcObject = null;
  connectSocket();
  setStatus("Entrando...");
}

render();
setupDiscord();
connectSocket();
